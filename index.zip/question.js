'use strict';

module.exports = {

    returnAllQuestions: function(){
        const questionArray = [
                      "The American President in 1928 was Herbert Hoover ? " ,
                      "The Wall Street Crash happened in 1941. " ,
                      "The Democrats won the elections in 1932. "
                    ];
        return questionArray;
    }

};
